# pygraphvis

A tiny python module which provides an interactive force-directed graph layout visualiser.

Inspired by [RetroMelon/GraPy](https://github.com/RetroMelon/GraPy), but implemented completely from scratch for Python 3.
